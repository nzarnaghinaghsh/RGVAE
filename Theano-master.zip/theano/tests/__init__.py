from __future__ import absolute_import, print_function, division

try:
    from theano.tests.main import main, TheanoNoseTester
except ImportError:
    pass
